﻿var log = console.log;
var score = 61;
if (score >= 60)
  log("及格");
else
  log("不及格");