var log = console.log;

var x =5, y=7;
var s = "Hello! ";
t = s + x;
z = x * y;
log("x="+x+"\ny="+y+"\ns="+s+"\nt="+t+"\nz="+z);