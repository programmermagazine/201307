var x;
var friends = new Array();
friends[0] = "John";
friends[1] = "Mary";
friends[2] = "George";
for (p in friends) {
  document.write(p + ":"+ friends[p] + "<br/>");
}